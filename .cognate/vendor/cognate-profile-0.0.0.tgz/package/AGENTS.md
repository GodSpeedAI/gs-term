# packages/profile

No kernel primitives here — only selection and validation over a
caller-supplied component registry. Never silently drop an unresolved
component; always report it with a reason. Don't edit `test/`.
