# react — agent guide
Hooks adapt client Readables; keep derived Readables cached per id so snapshots stay stable. Never import Astryx or UI kits here.
