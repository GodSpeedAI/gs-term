# proto — agent guide
Generated code only. Never hand-edit `src/gen/**`; change `proto/` (canonical, owned elsewhere)
and re-run `bun scripts/generate.ts`, then commit the diff. `src/index.ts` is the only hand-written
file — keep its re-exports in sync with the message/enum/service files under `src/gen`.
