# client — agent guide
Everything shown to users must be derivable from events or service calls; never cache authority. No React or Astryx imports (checked by tests/architecture).
