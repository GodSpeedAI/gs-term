# protocol-connect-bun — agent guide
Bun transport only. Keep limits enforced before parsing; never trust identity from message bodies. Real authentication must replace `devTokenAuthenticator` in production deployments.
